
# 📘 Microjob Platform – Full Technical Documentation & Handover

## 📌 Project Overview

This project is a **micro-job marketplace** similar to **RapidWorkers**, built as a **production-grade MVP** with **real escrow-based payments**, not just CRUD operations.

The platform connects:

* **Employers** → post micro tasks & fund them
* **Workers** → complete tasks & get paid
* **Admin** → controls approvals and money flow

The core goal of this project was to **design correct money flow**, not UI polish.

---

## 🧱 Core Design Principles

1. **Money safety first**
2. **Escrow must always balance**
3. **Role-based authority**
4. **No hidden side effects**
5. **Scope intentionally frozen**

This is **not** a toy project.

---

## 🛠 Tech Stack

### Backend

* **Node.js**
* **Express.js**
* **MySQL**
* **mysql2**
* **JWT (jsonwebtoken)**
* **bcrypt**

### Frontend

* Plain **HTML + JavaScript**
* No frameworks (intentionally simple for clarity)

---

## 🗂 Folder Structure

```
microjob-platform/
│
├── config/
│   └── db.js                  # MySQL connection
│
├── middleware/
│   └── authMiddleware.js      # JWT + role verification
│
├── routes/
│   ├── auth.js                # Login, register, wallet init
│   ├── jobs.js                # Jobs, submissions, escrow
│   ├── withdrawals.js         # Deposits, withdrawals
│   └── admin.js               # Admin dashboard APIs
│
├── public/
│   ├── admin.html             # Admin dashboard UI
│   ├── employer.html          # Employer dashboard UI
│   └── worker.html            # Worker dashboard UI
│
├── server.js                  # App entry point
├── .env                       # Environment variables
└── README.md / HANDOVER.md
```

---

## 🧑‍💼 User Roles & Permissions

### Admin

* Approves jobs
* Approves submissions
* Approves withdrawals
* Controls escrow release

### Employer

* Deposits money
* Creates jobs
* Views job status
* Views submissions for own jobs

### Worker

* Views approved jobs
* Submits proof
* Receives payment
* Requests withdrawal

---

## 💾 Database Schema (Important)

### users

```sql
id, name, email, password, role
```

### wallets

```sql
user_id,
balance,
locked_balance   -- escrow money
```

### jobs

```sql
id,
employer_id,
title,
description,
proof_required,
workers_needed,
pay_per_worker,
status
```

### job_submissions

```sql
id,
job_id,
worker_id,
proof,
status
```

### withdrawal_requests

```sql
id,
user_id,
amount,
method,
payout_address,
status
```

---

## 🔐 Authentication & Security

* JWT authentication
* Password hashing with bcrypt
* Role-based middleware enforcement
* No sensitive data exposed to frontend
* Admin-only routes strictly protected

---

## 💰 Wallet & Escrow Logic (MOST IMPORTANT)

### Wallet Fields

* `balance` → spendable money
* `locked_balance` → escrow (reserved funds)

---

## 🧾 COMPLETE MONEY FLOW (CRITICAL)

### 1️⃣ Employer Deposit

```
Employer → balance increases
```

### 2️⃣ Job Creation

```
No money moves
```

### 3️⃣ Admin Approves Job (ESCROW LOCK)

```
Employer balance ↓
Employer locked_balance ↑
```

### 4️⃣ Worker Submission

```
No money moves
```

### 5️⃣ Admin Approves Submission (ESCROW RELEASE)

```
Employer locked_balance ↓
Worker balance ↑
```

### 6️⃣ Worker Withdrawal

```
Worker balance ↓
(Admin approval required)
```

✔ No double spending
✔ No stuck funds
✔ No balance mismatch

---

## 🧠 Critical Escrow Fix (Recently Completed)

A major bug was fixed where:

* Escrow was locked
* Workers were paid
* But escrow was never released

This was **surgically fixed** in:

```
routes/jobs.js
POST /submissions/approve/:id
```

Now:

* Submission is approved first
* Escrow is released second
* Worker is credited last

This ensures **transaction safety**.

---

## 🖥 Dashboards (Status)

### Admin Dashboard

✔ View pending jobs
✔ Approve jobs (escrow lock)
✔ View submissions
✔ Approve submissions (escrow release)
✔ View withdrawals
✔ Approve withdrawals

### Employer Dashboard

✔ Deposit funds
✔ Create jobs
✔ View job status
✔ View submissions per job

### Worker Dashboard

✔ View approved jobs
✔ Submit proof
✔ View wallet balance
✔ Request withdrawal

UI is intentionally minimal.

---

## 📈 Progress Summary

### ✅ COMPLETED

* Authentication
* Role-based access
* Wallet system
* Escrow locking
* Escrow release
* Job lifecycle
* Withdrawals
* Admin controls
* Dashboards
* Scope freeze enforced

### ❌ INTENTIONALLY NOT DONE

These are **future upgrades**, not bugs:

* Refund unused escrow
* Job closing automation
* Wallet transaction history
* Pagination
* UI styling
* Email notifications
* Payment gateway integration

---

## 🚫 Scope Freeze Notice

⚠️ This project is **feature-frozen**.

No new features should be added **unless explicitly planned**.

This prevents:

* Infinite development loops
* Breaking escrow logic
* Scope creep

---

## 🧪 How to Run

```bash
npm install
node server.js
```

Visit:

* `/admin.html`
* `/employer.html`
* `/worker.html`

---

## 🎯 Intended Use

This project is suitable for:

* Portfolio demonstration
* Backend interviews
* Escrow system reference
* Foundation for scaling later

---

## 👤 Author

Built by **Kishore Reddy**
Focus: **backend systems, escrow logic, money safety**

---

## 🏁 Final Note to Next Developer / AI

⚠️ **Do NOT modify escrow logic casually.**

Any change to:

* `locked_balance`
* submission approval
* job approval

must be reasoned with **money flow diagrams first**.

This project is **correct as-is**.
