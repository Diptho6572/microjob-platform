require('dotenv').config();
const express = require('express');
const db = require('./config/db');

const authRoutes = require('./routes/auth');
const jobRoutes = require('./routes/jobs');
const withdrawalRoutes = require('./routes/withdrawals');
const adminRoutes = require('./routes/admin');
const employerRoutes = require('./routes/employer'); // ✅ STEP 21.2.2 added

const authMiddleware = require('./middleware/authMiddleware');

const app = express();
app.use(express.json());
app.use(express.static('public'));

app.use('/api/auth', authRoutes);
app.use('/api/jobs', jobRoutes);
app.use('/api/withdrawals', withdrawalRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/employer', employerRoutes); // ✅ STEP 21.2.2 added

// Public test route
app.get('/', (req, res) => {
  db.query('SELECT 1', (err) => {
    if (err) {
      return res.send('Database connection failed');
    }
    res.send('Server and database are connected');
  });
});

// 🔒 Protected test route
app.get('/api/protected', authMiddleware, (req, res) => {
  res.json({
    message: 'You accessed a protected route',
    user: req.user
  });
});

const PORT = process.env.PORT;

app.listen(PORT, () => {
  console.log('Server started on port ' + PORT);
});
