const express = require('express');
const db = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// ================================
// Admin-only middleware
// ================================
router.use(authMiddleware);

router.use((req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access only' });
  }
  next();
});

// ================================
// Admin Dashboard: Pending Jobs
// ================================
router.get('/jobs/pending', (req, res) => {
  const sql = `
    SELECT 
      jobs.id,
      jobs.title,
      jobs.description,
      jobs.status,
      users.name AS employer_name
    FROM jobs
    JOIN users ON jobs.employer_id = users.id
    WHERE jobs.status = 'pending'
  `;

  db.query(sql, (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Error fetching pending jobs' });
    }

    res.json(results);
  });
});

// ================================
// Admin Dashboard: Pending Submissions
// ================================
router.get('/submissions/pending', (req, res) => {
  const sql = `
    SELECT 
      js.id AS submission_id,
      jobs.title AS job_title,
      users.name AS worker_name,
      js.proof,
      js.status
    FROM job_submissions js
    JOIN jobs ON js.job_id = jobs.id
    JOIN users ON js.worker_id = users.id
    WHERE js.status = 'pending'
  `;

  db.query(sql, (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Error fetching submissions' });
    }

    res.json(results);
  });
});

// ================================
// Admin Dashboard: Pending Withdrawals
// ================================
router.get('/withdrawals/pending', (req, res) => {
  const sql = `
    SELECT 
      wr.id AS withdrawal_id,
      users.name AS worker_name,
      wr.amount,
      wr.method,
      wr.payout_address,
      wr.status
    FROM withdrawal_requests wr
    JOIN users ON wr.user_id = users.id
    WHERE wr.status = 'pending'
  `;

  db.query(sql, (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Error fetching withdrawals' });
    }

    res.json(results);
  });
});

// ================================
// Admin: Approve Job
// ================================
router.post('/jobs/approve/:id', (req, res) => {
  const jobId = req.params.id;

  const sql = `UPDATE jobs SET status = 'approved' WHERE id = ?`;

  db.query(sql, [jobId], (err, result) => {
    if (err) {
      return res.status(500).json({ message: 'Error approving job' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Job not found' });
    }

    res.json({ message: 'Job approved successfully' });
  });
});

// ================================
// Admin: Approve Submission (credit wallet)
// ================================
router.post('/submissions/approve/:id', (req, res) => {
  const submissionId = req.params.id;

  const fetchSql = `
    SELECT js.worker_id, jobs.pay_per_worker
    FROM job_submissions js
    JOIN jobs ON js.job_id = jobs.id
    WHERE js.id = ? AND js.status = 'pending'
  `;

  db.query(fetchSql, [submissionId], (err, results) => {
    if (err || results.length === 0) {
      return res.status(400).json({ message: 'Invalid or already processed submission' });
    }

    const { worker_id, pay_per_worker } = results[0];

    const walletSql = `
      UPDATE wallets
      SET balance = balance + ?
      WHERE user_id = ?
    `;

    db.query(walletSql, [pay_per_worker, worker_id], (err2) => {
      if (err2) {
        return res.status(500).json({ message: 'Failed to credit wallet' });
      }

      const approveSql = `
        UPDATE job_submissions
        SET status = 'approved'
        WHERE id = ?
      `;

      db.query(approveSql, [submissionId], (err3) => {
        if (err3) {
          return res.status(500).json({ message: 'Failed to approve submission' });
        }

        res.json({ message: 'Submission approved and wallet credited' });
      });
    });
  });
});

// ================================
// Admin: Approve Withdrawal
// ================================
router.post('/withdrawals/approve/:id', (req, res) => {
  const withdrawalId = req.params.id;

  const fetchSql = `
    SELECT wr.user_id, wr.amount, w.balance
    FROM withdrawal_requests wr
    JOIN wallets w ON wr.user_id = w.user_id
    WHERE wr.id = ? AND wr.status = 'pending'
  `;

  db.query(fetchSql, [withdrawalId], (err, results) => {
    if (err || results.length === 0) {
      return res.status(400).json({ message: 'Invalid or already processed withdrawal' });
    }

    const { user_id, amount, balance } = results[0];

    if (parseFloat(balance) < parseFloat(amount)) {
      return res.status(400).json({ message: 'Insufficient wallet balance' });
    }

    const walletSql = `
      UPDATE wallets
      SET balance = balance - ?
      WHERE user_id = ?
    `;

    db.query(walletSql, [amount, user_id], (err2) => {
      if (err2) {
        return res.status(500).json({ message: 'Failed to deduct wallet balance' });
      }

      const approveSql = `
        UPDATE withdrawal_requests
        SET status = 'approved'
        WHERE id = ?
      `;

      db.query(approveSql, [withdrawalId], (err3) => {
        if (err3) {
          return res.status(500).json({ message: 'Failed to approve withdrawal' });
        }

        res.json({ message: 'Withdrawal approved and wallet balance deducted' });
      });
    });
  });
});

module.exports = router;
