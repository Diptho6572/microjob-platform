const express = require('express');
const db = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// ================================
// Employer: deposit money
// ================================
router.post('/deposit', authMiddleware, (req, res) => {
  if (req.user.role !== 'employer') {
    return res.status(403).json({ message: 'Employer access only' });
  }

  const { amount } = req.body;

  if (!amount || amount <= 0) {
    return res.status(400).json({ message: 'Invalid deposit amount' });
  }

  const sql = `
    UPDATE wallets
    SET balance = balance + ?
    WHERE user_id = ?
  `;

  db.query(sql, [amount, req.user.id], (err) => {
    if (err) {
      return res.status(500).json({ message: 'Deposit failed' });
    }

    res.json({ message: 'Deposit successful' });
  });
});

// ================================
// Worker: request withdrawal
// ================================
router.post('/request', authMiddleware, (req, res) => {
  if (req.user.role !== 'worker') {
    return res.status(403).json({ message: 'Worker access only' });
  }

  const { amount, method, payout_address } = req.body;

  if (!amount || !method || !payout_address) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  if (amount <= 0) {
    return res.status(400).json({ message: 'Invalid withdrawal amount' });
  }

  const walletSql = `SELECT balance FROM wallets WHERE user_id = ?`;

  db.query(walletSql, [req.user.id], (err, results) => {
    if (err || results.length === 0) {
      return res.status(500).json({ message: 'Wallet not found' });
    }

    const balance = parseFloat(results[0].balance);

    if (amount > balance) {
      return res.status(400).json({ message: 'Insufficient balance' });
    }

    const withdrawSql = `
      INSERT INTO withdrawal_requests (user_id, amount, method, payout_address)
      VALUES (?, ?, ?, ?)
    `;

    db.query(
      withdrawSql,
      [req.user.id, amount, method, payout_address],
      (err2) => {
        if (err2) {
          return res.status(500).json({ message: 'Withdrawal request failed' });
        }

        res.json({
          message: 'Withdrawal request submitted and pending admin approval'
        });
      }
    );
  });
});

// ================================
// Admin: view pending withdrawals
// ================================
router.get('/pending', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access only' });
  }

  const sql = `
    SELECT 
      wr.id AS withdrawal_id,
      wr.user_id,
      wr.amount,
      wr.method,
      wr.payout_address,
      wr.status
    FROM withdrawal_requests wr
    WHERE wr.status = 'pending'
  `;

  db.query(sql, (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Error fetching withdrawals' });
    }

    res.json(results);
  });
});

// ================================
// Admin: approve withdrawal & deduct wallet
// ================================
router.post('/approve/:withdrawalId', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access only' });
  }

  const withdrawalId = req.params.withdrawalId;

  const fetchSql = `
    SELECT wr.user_id, wr.amount, w.balance
    FROM withdrawal_requests wr
    JOIN wallets w ON wr.user_id = w.user_id
    WHERE wr.id = ? AND wr.status = 'pending'
  `;

  db.query(fetchSql, [withdrawalId], (err, results) => {
    if (err || results.length === 0) {
      return res.status(400).json({ message: 'Invalid or already processed withdrawal' });
    }

    const { user_id, amount, balance } = results[0];

    if (parseFloat(balance) < parseFloat(amount)) {
      return res.status(400).json({ message: 'Insufficient wallet balance' });
    }

    const walletSql = `
      UPDATE wallets
      SET balance = balance - ?
      WHERE user_id = ?
    `;

    db.query(walletSql, [amount, user_id], (err2) => {
      if (err2) {
        return res.status(500).json({ message: 'Failed to deduct wallet balance' });
      }

      const approveSql = `
        UPDATE withdrawal_requests
        SET status = 'approved'
        WHERE id = ?
      `;

      db.query(approveSql, [withdrawalId], (err3) => {
        if (err3) {
          return res.status(500).json({ message: 'Failed to approve withdrawal' });
        }

        res.json({ message: 'Withdrawal approved and wallet balance deducted' });
      });
    });
  });
});

module.exports = router;
