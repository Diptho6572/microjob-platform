const express = require('express');
const db = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// ================================
// Employer: deposit money
// ================================
router.post('/deposit', authMiddleware, (req, res) => {
  if (req.user.role !== 'employer') {
    return res.status(403).json({ message: 'Employer access only' });
  }

  const { amount } = req.body;

  if (!amount || amount <= 0) {
    return res.status(400).json({ message: 'Invalid deposit amount' });
  }

  const sql = `
    UPDATE wallets
    SET balance = balance + ?
    WHERE user_id = ?
  `;

  db.query(sql, [amount, req.user.id], (err, result) => {
    if (err || result.affectedRows === 0) {
      return res.status(500).json({ message: 'Deposit failed' });
    }

    res.json({ message: 'Deposit successful' });
  });
});

module.exports = router;
