const express = require('express');
const db = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// ================================
// Employer creates a job
// ================================
router.post('/create', authMiddleware, (req, res) => {
  const { title, description, proof_required, workers_needed, pay_per_worker } = req.body;

  if (req.user.role !== 'employer') {
    return res.status(403).json({ message: 'Only employers can create jobs' });
  }

  if (!title || !description || !proof_required || !workers_needed || !pay_per_worker) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  const sql = `
    INSERT INTO jobs (employer_id, title, description, proof_required, workers_needed, pay_per_worker)
    VALUES (?, ?, ?, ?, ?, ?)
  `;

  db.query(sql, [
    req.user.id,
    title,
    description,
    proof_required,
    workers_needed,
    pay_per_worker
  ], err => {
    if (err) {
      return res.status(500).json({ message: 'Error creating job' });
    }

    res.json({ message: 'Job created successfully and pending admin approval' });
  });
});

// ================================
// Admin: view pending jobs
// ================================
router.get('/pending', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access only' });
  }

  const sql = `
    SELECT jobs.id, jobs.title, jobs.description, jobs.status, users.name AS employer_name
    FROM jobs
    JOIN users ON jobs.employer_id = users.id
    WHERE jobs.status = 'pending'
  `;

  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ message: 'Error fetching pending jobs' });
    res.json(results);
  });
});

// ================================
// 🔐 Admin: approve job (ESCROW LOCK)
// ================================
router.post('/approve/:id', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access only' });
  }

  const jobId = req.params.id;

  const fetchSql = `
    SELECT jobs.employer_id, jobs.workers_needed, jobs.pay_per_worker, wallets.balance
    FROM jobs
    JOIN wallets ON wallets.user_id = jobs.employer_id
    WHERE jobs.id = ? AND jobs.status = 'pending'
  `;

  db.query(fetchSql, [jobId], (err, results) => {
    if (err || results.length === 0) {
      return res.status(400).json({ message: 'Invalid or already approved job' });
    }

    const { employer_id, workers_needed, pay_per_worker, balance } = results[0];
    const totalCost = workers_needed * pay_per_worker;

    if (balance < totalCost) {
      return res.status(400).json({
        message: 'Employer does not have enough balance to approve this job'
      });
    }

    const lockSql = `
      UPDATE wallets
      SET balance = balance - ?, locked_balance = locked_balance + ?
      WHERE user_id = ?
    `;

    db.query(lockSql, [totalCost, totalCost, employer_id], err2 => {
      if (err2) return res.status(500).json({ message: 'Failed to lock escrow money' });

      const approveSql = `UPDATE jobs SET status = 'approved' WHERE id = ?`;

      db.query(approveSql, [jobId], err3 => {
        if (err3) return res.status(500).json({ message: 'Job approval failed' });

        res.json({
          message: 'Job approved and escrow money locked',
          escrow_locked: totalCost
        });
      });
    });
  });
});

// ================================
// Worker: view approved jobs
// ================================
router.get('/approved', authMiddleware, (req, res) => {
  if (req.user.role !== 'worker') {
    return res.status(403).json({ message: 'Worker access only' });
  }

  const sql = `
    SELECT jobs.id, jobs.title, jobs.description, jobs.proof_required,
           jobs.pay_per_worker, users.name AS employer_name
    FROM jobs
    JOIN users ON jobs.employer_id = users.id
    WHERE jobs.status = 'approved'
  `;

  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ message: 'Error fetching jobs' });
    res.json(results);
  });
});

// ================================
// Worker: submit job proof
// ================================
router.post('/submit/:jobId', authMiddleware, (req, res) => {
  if (req.user.role !== 'worker') {
    return res.status(403).json({ message: 'Worker access only' });
  }

  const { proof } = req.body;
  const jobId = req.params.jobId;

  if (!proof) {
    return res.status(400).json({ message: 'Proof is required' });
  }

  const sql = `
    INSERT INTO job_submissions (job_id, worker_id, proof)
    VALUES (?, ?, ?)
  `;

  db.query(sql, [jobId, req.user.id, proof], err => {
    if (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        return res.status(400).json({ message: 'You already submitted this job' });
      }
      return res.status(500).json({ message: 'Error submitting job' });
    }

    res.json({ message: 'Job submitted successfully and pending review' });
  });
});

// ================================
// 🔓 Admin: approve submission (RELEASE ESCROW)
// ================================
router.post('/submissions/approve/:id', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access only' });
  }

  const submissionId = req.params.id;

  const fetchSql = `
    SELECT js.worker_id, jobs.employer_id, jobs.pay_per_worker
    FROM job_submissions js
    JOIN jobs ON js.job_id = jobs.id
    WHERE js.id = ? AND js.status = 'pending'
  `;

  db.query(fetchSql, [submissionId], (err, results) => {
    if (err || results.length === 0) {
      return res.status(400).json({ message: 'Invalid or already approved submission' });
    }

    const { worker_id, employer_id, pay_per_worker } = results[0];

    // 1️⃣ Mark submission approved
    const approveSql = `
      UPDATE job_submissions
      SET status = 'approved'
      WHERE id = ?
    `;

    db.query(approveSql, [submissionId], err1 => {
      if (err1) return res.status(500).json({ message: 'Submission approval failed' });

      // 2️⃣ Release escrow
      const releaseSql = `
        UPDATE wallets
        SET locked_balance = locked_balance - ?
        WHERE user_id = ? AND locked_balance >= ?
      `;

      db.query(releaseSql, [pay_per_worker, employer_id, pay_per_worker], err2 => {
        if (err2) return res.status(500).json({ message: 'Escrow release failed' });

        // 3️⃣ Pay worker
        const creditSql = `
          UPDATE wallets
          SET balance = balance + ?
          WHERE user_id = ?
        `;

        db.query(creditSql, [pay_per_worker, worker_id], err3 => {
          if (err3) return res.status(500).json({ message: 'Worker credit failed' });

          res.json({ message: 'Submission approved and paid from escrow' });
        });
      });
    });
  });
});

module.exports = router;
