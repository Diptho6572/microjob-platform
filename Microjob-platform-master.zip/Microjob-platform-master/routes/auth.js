const jwt = require('jsonwebtoken');
const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// ================================
// Register
// ================================
router.post('/register', (req, res) => {
  const { name, email, password, role } = req.body;

  if (!name || !email || !password || !role) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  const hashedPassword = bcrypt.hashSync(password, 10);

  const sql = `
    INSERT INTO users (name, email, password, role)
    VALUES (?, ?, ?, ?)
  `;

  db.query(sql, [name, email, hashedPassword, role], (err, result) => {
    if (err) {
      return res.status(500).json({ message: 'User already exists or error occurred' });
    }

    // ================================
    // Create wallet for new user
    // ================================
    const walletSql = 'INSERT INTO wallets (user_id) VALUES (?)';

    db.query(walletSql, [result.insertId], (walletErr) => {
      if (walletErr) {
        return res.status(500).json({ message: 'User created but wallet failed' });
      }

      res.json({ message: 'User registered successfully' });
    });
  });
});

// ================================
// Login
// ================================
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' });
  }

  const sql = 'SELECT * FROM users WHERE email = ?';

  db.query(sql, [email], (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Database error' });
    }

    if (results.length === 0) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const user = results[0];

    const isMatch = bcrypt.compareSync(password, user.password);

    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '1d' }
    );

    res.json({
      message: 'Login successful',
      token: token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  });
});

// ================================
// Get wallet balance (Worker)
// ================================
router.get('/wallet', authMiddleware, (req, res) => {
  const sql = `SELECT balance FROM wallets WHERE user_id = ?`;

  db.query(sql, [req.user.id], (err, results) => {
    if (err || results.length === 0) {
      return res.status(500).json({ message: 'Wallet not found' });
    }

    res.json({ balance: results[0].balance });
  });
});

module.exports = router;
